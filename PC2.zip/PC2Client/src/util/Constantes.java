package util;

public class Constantes {
	public static int ID_SERVICIO = 1;
}
